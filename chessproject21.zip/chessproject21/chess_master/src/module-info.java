/**
 * 
 */
/**
 * 
 */
module chess_master {
	requires java.desktop;
}